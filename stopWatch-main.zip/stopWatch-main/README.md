# stopWatch

> Stop Watch Using Vanilla Javascript
  * Start Timer
  * Pause, Resume Timer
  * Reset Timer
  
  #### 👇 Step By Step Video Tutorial 
  [![Watch the video](https://img.youtube.com/vi/oMwaMYwHkS8/default.jpg)](https://youtu.be/oMwaMYwHkS8)
  
# Preview
![stopWatch](https://user-images.githubusercontent.com/62636620/209506698-98d5f0de-b188-4134-b385-55845b211493.gif)
